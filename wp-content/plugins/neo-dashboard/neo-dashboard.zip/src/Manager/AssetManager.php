<?php
declare(strict_types=1);

namespace NeoDashboard\Core\Manager;

use NeoDashboard\Core\Router;
use NeoDashboard\Core\Logger;

class AssetManager
{
    private const BOOTSTRAP_VERSION = '5.3.2';

    /**
     * Registriert die Hooks für unser eigenständiges Blank‑Template:
     * - neo_dashboard_head   → CSS
     * - neo_dashboard_footer → JS
     * - show_admin_bar       → Admin‑Bar ausblenden auf Dashboard‑Seiten
     */
    public function register(): void
    {
        Logger::info('AssetManager:register');

        // Wird im Template ausgeführt
        add_action( 'neo_dashboard_head',   [ $this, 'printHeadAssets' ],   5 );
        add_action( 'neo_dashboard_footer', [ $this, 'printFooterAssets' ], 5 );
        add_filter( 'show_admin_bar',       [ $this, 'maybeHideAdminBar' ] );
    }

    /**
     * Gibt alle benötigten <link>‑Tags für CSS im <head> aus.
     */
    public function printHeadAssets(): void
    {
        if ( ! $this->isDashboardPage() ) {
            return;
        }

        // Bootstrap CSS
        echo '<link rel="stylesheet" '
           . 'href="https://cdn.jsdelivr.net/npm/bootstrap@' . self::BOOTSTRAP_VERSION . '/dist/css/bootstrap.min.css"'
           . ' />';

        // Bootstrap Icons
        echo '<link rel="stylesheet" '
           . 'href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css"'
           . ' />';

        // Core‑CSS
        echo '<link rel="stylesheet" '
           . 'href="' . esc_url( plugin_dir_url( NEO_DASHBOARD_PLUGIN_FILE ) . 'assets/dashboard.css' ) . '"'
           . ' />';

        // Plugin CSS dynamisch über Hook laden
        $section = get_query_var( Router::QUERY_VAR_SECTION, '' );
        do_action('neo_dashboard_enqueue_plugin_assets_css', $section);

    }

    /**
     * Gibt alle benötigten <script>‑Tags für JS vor </body> aus.
     */
    public function printFooterAssets(): void
    {
        if ( ! $this->isDashboardPage() ) {
            return;
        }

        // Bootstrap Bundle JS
        echo '<script src="https://cdn.jsdelivr.net/npm/bootstrap@'
           . self::BOOTSTRAP_VERSION
           . '/dist/js/bootstrap.bundle.min.js"></script>';

        // Core‑JS
        echo '<script src="'
           . esc_url( plugin_dir_url( NEO_DASHBOARD_PLUGIN_FILE ) . 'assets/js/dashboard.js' )
           . '"></script>';

        // Plugin JS dynamisch über Hook laden
        $section = get_query_var( Router::QUERY_VAR_SECTION, '' );
        do_action('neo_dashboard_enqueue_plugin_assets_js', $section);

    }

    /**
     * Blendet die Admin‑Bar auf Dashboard‑Seiten aus.
     */
    public function maybeHideAdminBar( bool $show ): bool
    {
        return $this->isDashboardPage() ? false : $show;
    }

    /**
     * Prüft, ob wir uns auf der Haupt‑Dashboardseite oder einer Section‑URL befinden.
     */
    private function isDashboardPage(): bool
    {
        return is_page( 'neo-dashboard' )
            || ( get_query_var( Router::QUERY_VAR_SECTION, '' ) !== '' );
    }
}
