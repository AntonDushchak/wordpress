<?php
declare(strict_types=1);

namespace NeoDashboard\Core\Manager;

use NeoDashboard\Core\Registry;
use NeoDashboard\Core\Logger;

class NotificationManager
{
    /**
     * Hook für das Registrieren von Notifications.
     */
    public function registerDefault(): void
    {
        add_action('neo_dashboard_register_notification', [ $this, 'register' ]);
    }

    /**
     * Registriert eine neue Notification in der zentralen Registry.
     *
     * @param array{
     *   id: string,
     *   message?: string,
     *   type?: string,
     *   dismissible?: bool,
     *   priority?: int,
     *   roles?: array|null
     * } $args
     * @return string Der generierte Handle (Notification‑ID)
     */
    public function register(array $args): string
    {
        Logger::info('NotificationManager:register', [
            'args' => $args['id']
        ]);

        $id = sanitize_key((string) $args['id']);
        Registry::instance()->addNotification($id, $args);
        return $id;
    }

    /**
     * Gibt alle registrierten Notifications über die Registry zurück,
     * sortiert nach Priority.
     *
     * @return array<string, array>
     */
    public function getNotifications(): array
    {
        $notifications = Registry::instance()->getNotifications();
        uasort(
            $notifications,
            static fn($a, $b) => (int)($a['priority'] ?? 10) <=> (int)($b['priority'] ?? 10)
        );
        return $notifications;
    }
}
