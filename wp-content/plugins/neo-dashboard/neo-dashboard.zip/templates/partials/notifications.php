<?php
/**
 * Partial: Notifications
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>
<?php foreach ( $notifications as $note ) : ?>
    <div class="alert alert-<?php echo esc_attr( $note['type'] ?? 'info' ); ?><?php echo $note['dismissible'] ? ' alert-dismissible fade show' : ''; ?>" role="alert">
        <?php echo wp_kses_post( $note['message'] ); ?>
        <?php if ( $note['dismissible'] ) : ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        <?php endif; ?>
    </div>
<?php endforeach; ?>
